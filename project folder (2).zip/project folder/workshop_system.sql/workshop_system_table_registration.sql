
-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `name`, `email`, `password`, `cpassword`) VALUES
(14, 'inzi', 'inzii@gmail.com', '$2y$10$zluQ2scFvlcdiSrgpLaDIu6maXOrRN9/pCjrEY3A8l3tfnD7ZsJb6', '$2y$10$sFb.DOo/Md0az.CAClVRHu5q4c4Wl7MhQIW7F1JO4Xc.nz3ohYufm'),
(15, 'raf', 'raf@gmail.com', '$2y$10$4NmZ8xnXfdv.VxUM/vbBw.gLxw//t/RuEHI0rViM9Uix53/Zy8o6i', '$2y$10$fCmaf9n8caPOKK66dmKDS.WRCUi14JykDELoGQJR8mYcAuJ.QqLRe'),
(16, 'karam', 'karam@gmail.com', '$2y$10$Bb.sPH9z8OmlZ6jXGRlsi.jyRUJym7aiVzGkYDuaKTTeoE5oAf0Ty', '$2y$10$NCuXcySAa1tKzo8ZA6ghnub1Q0KWkwBreomojJFcThhLWKv2UiSna'),
(17, 'adil', 'adil@gmail.com', '$2y$10$u1uD2fWu99tymgeq5HKBaOuU3eGYjrZ33K.jNrTmHuut3LZ3zUbAm', '$2y$10$lgdeNT7c.ln4NIWUCZLPXujQUx0C0VxOC7.pdzROIWJXArqz2W73q'),
(18, 'qadi', 'qadir@gmail.com', '$2y$10$VWps./QvCfzeiqOE0u864Ohs.2ZKR2/56IJI32ML2.0Grrnnvgevu', '$2y$10$x38d3ewxgv3zHy.iPQvslerxul5W6pFoKQqP175endVTtMQGWCVdW'),
(19, 'inzii', 'inz@gmail.com', '$2y$10$P4KC453pDz9Tk1nL.YFWyuWo6Gv3pyplrZmEHmezB7QM7H3YsEjKy', '$2y$10$ETdlmxPqUetm0r3sbS9y/eugl3MQ6ptTV9E.JhIVzfWb5RudSNbt.');
