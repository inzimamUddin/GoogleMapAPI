
-- --------------------------------------------------------

--
-- Table structure for table `add_workshop`
--

CREATE TABLE `add_workshop` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `ownername` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `latitude` varchar(255) NOT NULL,
  `longitude` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_workshop`
--

INSERT INTO `add_workshop` (`id`, `name`, `ownername`, `address`, `contact`, `latitude`, `longitude`) VALUES
(32, 'ptdc', 'lkjl', 'chitral town', '3423423', '35.85982933731695', '71.78595027696451'),
(33, 'city ws', 'karam', 'chitral', '3423423', '35.854994651792865', ' 71.78715190659649'),
(34, 'view', 'khan', 'goldur', '34234', '35.852542414425315', '71.7803069092286'),
(35, 'brothers', 'ali', 'danin', '3324234', '35.863446463235874', '71.78882560502727'),
(36, 'jfjj', 'akdj', 'orghoch', '4982934', '35.86407246416288', ' 71.79624997515184'),
(37, 'ali', 'kha n', 'jughur', '3423', '35.856472891035295', ' 71.78985558889595');
